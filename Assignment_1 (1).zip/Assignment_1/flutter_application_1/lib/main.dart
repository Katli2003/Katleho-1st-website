import 'package:flutter/material.dart';

/*Student Numbers : 222001049 , 222004623 , 223046395 , 223059704 , 223042902 , 223009405 , 222005563
  Student Name : Mphanya MW ,Seatlholo KG , Ncapayi SS , Lebusho K , Kgware B , Leteane NMK , Lebona L

  */

void main() {
  runApp(const ePayApp());
}

// ignore: camel_case_types
class ePayApp extends StatelessWidget {
  const ePayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: MainMenu());
  }
}

class MainMenu extends StatelessWidget {
  const MainMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Welcome to ePay',
          style: TextStyle(color: Colors.white), // Text color set to white
        ),
        backgroundColor: Colors.blue, // App bar background color
      ),
      backgroundColor: Colors.green, // Set background color to green
      body: Center(
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center, // Center the content vertically
          children: [
            Container(
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
              ),
              child: const Icon(Icons.attach_money,
                  size: 100, color: Colors.green), // Dollar icon with circle
            ),
            const SizedBox(height: 20), // Space between elements
            const Text(
              'More Money in Your Pocket',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold), // Highlighted text
            ),
            const SizedBox(height: 20), // Space between elements
            ePayTile(context, 'Main Menu',
                navigateTo: const SecondPage()), // Tile with navigation
            ePayTile(context, 'Check Rates'), // Tile
            ePayTile(context, 'WhatsApp ePay'), // Tile
            const SizedBox(height: 20), // Space between elements
            const Text(
              ' \t\t\t\t\t\t\t Forgot Your Pin? \n Dial *134*542# to Reset it',
              style: TextStyle(
                  color: Colors.black, fontSize: 16), // Instruction text
            ),
          ],
        ),
      ),
    );
  }

  // Helper method to create tiles
  Widget ePayTile(BuildContext context, String text, {Widget? navigateTo}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10), // Vertical padding
      child: SizedBox(
        width: MediaQuery.of(context).size.width *
            0.8, // Set tile width to 80% of screen width
        child: ListTile(
          tileColor: Colors.black, // Tile background color
          textColor: Colors.white, // Tile text color
          title: Text(text), // Tile text
          trailing: const Icon(Icons.arrow_forward,
              color: Colors.green), // Arrow icon
          onTap: () {
            if (navigateTo != null) {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        navigateTo), // Navigate to the specified page
              );
            }
          },
        ),
      ),
    );
  }
}

class SecondPage extends StatelessWidget {
  const SecondPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back,
              color: Colors.white), // Back arrow color set to white
          onPressed: () {
            Navigator.pop(context); // Navigate back to the main menu page
          },
        ),
        title: const Text(
          'ePay Main Menu',
          style: TextStyle(color: Colors.white), // Text color set to white
        ),
        backgroundColor: Colors.blue, // App bar background color
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0), // Add padding to the entire body
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                    vertical: 8.0), // Add padding to each ListTile
                child: ListTile(
                  leading: const Icon(Icons.people, color: Colors.green),
                  title: const Text('Recipients',
                      style: TextStyle(
                        color: Colors.black,
                      )),
                  trailing:
                      const Icon(Icons.arrow_forward, color: Colors.green),
                  tileColor: Colors.white,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => RecipientsPage()),
                    );
                  },
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(
                    vertical: 8.0), // Add padding to each ListTile
                child: ListTile(
                  leading: Icon(Icons.person, color: Colors.green),
                  title:
                      Text('My Profile', style: TextStyle(color: Colors.black)),
                  trailing: Icon(Icons.arrow_forward, color: Colors.green),
                  tileColor: Colors.white,
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(
                    vertical: 8.0), // Add padding to each ListTile
                child: ListTile(
                  leading: Icon(Icons.phone, color: Colors.green),
                  title: Text('Contact ePay',
                      style: TextStyle(color: Colors.black)),
                  trailing: Icon(Icons.arrow_forward, color: Colors.green),
                  tileColor: Colors.white,
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(
                    vertical: 8.0), // Add padding to each ListTile
                child: ListTile(
                  leading: Icon(Icons.exit_to_app, color: Colors.green),
                  title:
                      Text('Sign out', style: TextStyle(color: Colors.black)),
                  trailing: Icon(Icons.arrow_forward, color: Colors.green),
                  tileColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ignore: use_key_in_widget_constructors
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MainMenuPage(),
    );
  }
}

// ignore: use_key_in_widget_constructors
class MainMenuPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // ignore: prefer_const_constructors
        title: Text('Main Menu'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => RecipientsPage()),
            );
          },
          // ignore: prefer_const_constructors
          child: Text('Go to Recipients Page'),
        ),
      ),
    );
  }
}

class RecipientsPage extends StatelessWidget {
  RecipientsPage({super.key});

  // List of recipients
  final List<Map<String, String>> recipients = [
    {'name': 'Wiseman', 'phone': '078600000'},
    {'name': 'siya', 'phone': '074444313'},
    {'name': 'Keke', 'phone': '089094323'},
    {'name': 'Paso', 'phone': '078654323'},
    {'name': 'Lebona', 'phone': '075654323'},
    {'name': 'Katleho', 'phone': '0679424884'},
    {'name': 'Kat', 'phone': '0710562262'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          // ignore: prefer_const_constructors
          icon: Icon(Icons.arrow_back,
              color: Colors.white), // Back arrow color set to white
          onPressed: () {
            Navigator.pop(context); // Navigate back to the main menu page
          },
        ),
        // ignore: prefer_const_constructors
        title: Text(
          'List of Recipients',
          // ignore: prefer_const_constructors
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.blue, // App bar background color
      ),
      body: ListView.separated(
        itemCount: recipients.length, // Number of recipients
        itemBuilder: (context, index) {
          return ListTile(
            // ignore: prefer_const_constructors
            leading: CircleAvatar(
              backgroundColor: Colors.grey, // Avatar background color
              // ignore: prefer_const_constructors
              child: Icon(Icons.person, color: Colors.white), // Person icon
            ),
            title: Text(
              recipients[index]['name']!,
              // ignore: prefer_const_constructors
              style: TextStyle(color: Colors.black), // Recipient name
            ),
            subtitle: Text(
              recipients[index]['phone']!,
              // ignore: prefer_const_constructors
              style: TextStyle(color: Colors.black), // Recipient phone number
            ),
            trailing: TextButton(
              onPressed: () {
                // Add your send money logic here
              },
              // ignore: prefer_const_constructors
              child: Text(
                'Send Money',
                // ignore: prefer_const_constructors
                style: TextStyle(color: Colors.black), // Button text color
              ),
            ),
          );
        },
        separatorBuilder: (context, index) {
          // ignore: prefer_const_constructors
          return Divider(); // Line separator
        },
      ),
    );
  }
}
